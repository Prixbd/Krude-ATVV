package com.example.SUAMAE.Controller;

import com.example.SUAMAE.Service.UsuarioService;
import com.example.SUAMAE.model.Usuario;
import com.example.SUAMAE.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {

    private UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping
    public ResponseEntity <String> salvar(@Valid @RequestBody Usuario usuario) {
        usuarioService.salvar(usuario);
        String mensagem = "Usuário " + usuario.getNome() + " cadastrado com sucesso.";
        return ResponseEntity.status(HttpStatus.CREATED).body(mensagem);
    }

    @GetMapping
    public List<Usuario> listarTodos() {
        return usuarioService.listarUsuario();
    }

    @PutMapping
    public ResponseEntity<String> atualizar(@Valid @RequestBody Usuario usuario){

        usuarioService.atualizar(usuario);
        return ResponseEntity.ok().body("Usuário atualizado com sucesso.");
    }

    @DeleteMapping("/{email}")
    public ResponseEntity<String> excluir(@PathVariable String email) {
        usuarioService.excluir(email);
        return ResponseEntity.ok().body("Usuário excluido com sucesso.");
    }


}
