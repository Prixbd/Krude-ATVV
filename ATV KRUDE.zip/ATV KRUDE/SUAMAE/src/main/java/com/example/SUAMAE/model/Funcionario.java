package com.example.SUAMAE.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.annotations.Cascade;

@Entity
@Table (name = "Table_Funcionario")
public class Funcionario
{

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)

    @NotBlank(message = "O Nome é Obrigatorio.")
    private String nome;

    @NotBlank(message = "O CPF é Obrigatorio.")
    private String cpf;

    @NotBlank(message = "O RG é Obrigatorio.")
    private String rg;

    @NotBlank(message = "A Matricula é Obrigatorio.")
    private String matricula;

    @NotBlank(message = "A Data de Nascimento é Obrigatorio.")
    private String dataNascimento;

    @Enumerated (EnumType.STRING)
    private Sexo sexo;

    @Enumerated (EnumType.STRING)
    private Setor setor;


    private double salario;

     @NotBlank(message = "O Telefone é Obrigatorio.")
     private String telefone;

     @NotBlank(message = "O E-Mail é Obrigatorio.")
     private String email;

     @OneToOne(cascade = CascadeType.ALL)
     private Endereco endereco;



    public Funcionario () {
    }

}
