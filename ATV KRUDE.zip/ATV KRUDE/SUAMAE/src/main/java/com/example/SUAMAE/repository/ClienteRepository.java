package com.example.SUAMAE.repository;

import com.example.SUAMAE.model.Cliente;
import com.example.SUAMAE.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}
